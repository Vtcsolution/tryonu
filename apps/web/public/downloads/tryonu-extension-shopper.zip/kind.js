globalThis.TRYONU_KIND = "shopper";
